/*
 * Criado por: Henrique Dreyer
 * Data Inicio: 17/08/2015
 * 
 * 2015.2 Compiladores - Silvio Bandeira
 * 
 *	site: https://github.com/HenriqueDreyer/Compiladores
 */

public class TokenTable {
	
	public TokenTable(){}
	
	public Enum isPalavraReservada(String lexema){
		switch(lexema){
		case "main":
			return Gramatica.MAIN;
		case "int":
			return Gramatica.INT;
		case "float":
			return Gramatica.FLOAT;
		case "char":
			return Gramatica.CHAR;
		case "if":
			return Gramatica.IF;
		case "else":
			return Gramatica.ELSE;
		case "while":
			return Gramatica.WHILE;
		case "do":
			return Gramatica.DO;
		default:
			return Gramatica.ID;
		}
	}
	
	public Enum getMAIN(){
		return Gramatica.MAIN;
	}
	
	public Enum getEOF(){
		return Gramatica.EOF;
	}
	public Enum getID(){
		return Gramatica.ID;
	}
	
	public Enum getINT(){
		return Gramatica.INT;
	}
	public Enum getFLOAT(){
		return Gramatica.FLOAT;
	}
	public Enum getCHAR(){
		return Gramatica.CHAR;
	}
	public Enum getTIPOINT(){
		return Gramatica.TIPOINT;
	}
	public Enum getTIPOFLOAT(){
		return Gramatica.TIPOFLOAT;
	}
	public Enum getTIPOCHAR(){
		return Gramatica.TIPOCHAR;
	}
	public Enum getIF(){
		return Gramatica.IF;
	}
	public Enum getELSE(){
		return Gramatica.ELSE;
	}	
	public Enum getWHILE(){
		return Gramatica.WHILE;
	}
	public Enum getDO(){
		return Gramatica.DO;
	}
	public Enum getPONTOVIRGULA(){
		return Gramatica.PONTOVIRGULA;
	}
	public Enum getVIRGULA(){
		return Gramatica.VIRGULA;
	}
	public Enum getABRECHAVE(){
		return Gramatica.ABRECHAVE;
	}
	public Enum getABREPARENTESES(){
		return Gramatica.ABREPARENTESES;
	}
	public Enum getFECHACHAVE(){
		return Gramatica.FECHACHAVE;
	}
	public Enum getFECHAPARENTESES(){
		return Gramatica.FECHAPARENTESES;
	}
	public Enum getSOMA(){
		return Gramatica.SOMA;
	}
	public Enum getSUBTRACAO(){
		return Gramatica.SUBTRACAO;
	}
	public Enum getDIVISAO(){
		return Gramatica.DIVISAO;
	}
	public Enum getMULTIPLICACAO(){
		return Gramatica.MULTIPLICACAO;
	}
	public Enum getMAIOR(){
		return Gramatica.MAIOR;
	}
	public Enum getMAIORIGUAL(){
		return Gramatica.MAIORIGUAL;
	}
	public Enum getMENOR(){
		return Gramatica.MENOR;
	}
	public Enum getMENORIGUAL(){
		return Gramatica.MENORIGUAL;
	}
	public Enum getIGUAL(){
		return Gramatica.IGUAL;
	}
	public Enum getATRIBUICAO(){
		return Gramatica.ATRIBUICAO;
	}
	public Enum getDIFERENCA(){
		return Gramatica.DIFERENCA;
	}
}
