/*
 * Criado por: Henrique Dreyer
 * Data Inicio: 17/08/2015
 * 
 * 2015.2 Compiladores - Silvio Bandeira
 * 
 *	site: https://github.com/HenriqueDreyer/Compiladores
 */


import java.io.FileReader;
import java.io.IOException;


public class AnalizadorLexico {	
	FileReader arquivo;
	AnalizadorLexicoException Exception = new AnalizadorLexicoException();
	TokenTable tokenTable = new TokenTable();
	public static int linha = 1;
	public static int coluna = 0;
	public static char caracter = ' ';
	public static final char EoF = '\uffff';
	public static Enum palavraReservada;
	
	public AnalizadorLexico(FileReader arquivo){
		this.arquivo = arquivo;
	}
	
	public Token Scanner() throws Exception{		
		
		
			while(caracter != EoF){			
				String lexema = "";
				
				while(caracter == ' ' || caracter == '\n' || caracter == '\r' || caracter == '\t'){
					proximoToken();
				}
				
				if(caracter == EoF){
					return new Token(linha, coluna, tokenTable.getEOF(), "EndOfFile");
				
				}else if(Character.isLetter(caracter) || caracter == '_'){
					
					while(Character.isLetterOrDigit(caracter) || caracter == '_'){
						lexema+=caracter;
						proximoToken();
					}
					
					palavraReservada = tokenTable.isPalavraReservada(lexema);
					return new Token(linha, coluna, palavraReservada, lexema);
					
					
				}else if(Character.isDigit(caracter)){
					lexema+=caracter;
					proximoToken();
					
					while(Character.isDigit(caracter)){
						lexema+=caracter;
						proximoToken();
					}
					
					if(caracter == '.'){
						lexema+=caracter;
						proximoToken();
						
						if(!Character.isDigit(caracter)){
							Exception.FloatException(linha, coluna, lexema);
						}
						
						while(Character.isDigit(caracter)){
							lexema+=caracter;
							proximoToken();
						}
						return new Token(linha, coluna, tokenTable.getTIPOFLOAT(), lexema);
						
					}
					
					return new Token(linha, coluna, tokenTable.getTIPOINT(), lexema);
					
				}else if(caracter == '.'){
					lexema+=caracter;
					proximoToken();
					
					if(!Character.isDigit(caracter)){
						Exception.FloatException(linha, coluna, lexema);
					}
					
					while(Character.isDigit(caracter)){
						lexema+=caracter;
						proximoToken();
					}
					return new Token(linha, coluna, tokenTable.getTIPOFLOAT(), lexema);
					
				}else if(caracter == '\''){
					lexema+=caracter;
					proximoToken();
					
					if(!Character.isLetterOrDigit(caracter)){
						Exception.CharException(linha, coluna, lexema);
					}
					
					lexema+=caracter;
					proximoToken();
					
					if(caracter != '\''){											
						Exception.CharException(linha, coluna, lexema);
					}
					
					lexema+=caracter;
					proximoToken();
					return new Token(linha, coluna, tokenTable.getTIPOCHAR(), lexema);
					
				}else if(caracter == '+'){
					lexema+=caracter;
					proximoToken();
					return new Token(linha, coluna, tokenTable.getSOMA(), lexema);
					
				}else if(caracter == '-'){
					lexema+=caracter;
					proximoToken();
					return new Token(linha, coluna, tokenTable.getSUBTRACAO(), lexema);
					
				}else if(caracter == '*'){
					lexema+=caracter;
					proximoToken();
					return new Token(linha, coluna, tokenTable.getMULTIPLICACAO(), lexema);
					
				}else if(caracter == '/'){
					lexema+=caracter;
					proximoToken();
					
					if(caracter == '/'){
						while(caracter != '\n'){
							lexema+=caracter;
							proximoToken();
						}
					}
					
					if(caracter == '*'){
						lexema+=caracter;
						proximoToken();
						while(true){							
							if(caracter == '*'){
								proximoToken();
								if(caracter == '/'){									
									proximoToken();
									break;
								}else if(caracter == EoF){
									Exception.ComentarioException(linha, coluna, lexema);
								}
								
							}else if(caracter == EoF){
								Exception.ComentarioException(linha, coluna, lexema);
							}
							proximoToken();
						}
						
					}else {
						return new Token(linha, coluna, tokenTable.getDIVISAO(), lexema);
					}
					
				}else if(caracter == '='){
					lexema+=caracter;
					proximoToken();
					
					if(caracter == '='){
						lexema+=caracter;
						proximoToken();
						return new Token(linha, coluna, tokenTable.getIGUAL(), lexema);
					
					}else{
						return new Token(linha, coluna, tokenTable.getATRIBUICAO(), lexema);
					}
					
					
				}else if(caracter == '<'){
					lexema+=caracter;
					proximoToken();
					
					if(caracter == '='){
						lexema+=caracter;
						proximoToken();
						return new Token(linha, coluna, tokenTable.getMENORIGUAL(), lexema);
						
					}else{
						return new Token(linha, coluna, tokenTable.getMENOR(), lexema);
					}
					
				}else if(caracter == '>'){
					lexema+=caracter;
					proximoToken();
					
					if(caracter == '='){
						lexema+=caracter;
						proximoToken();
						return new Token(linha, coluna, tokenTable.getMAIORIGUAL(), lexema);
					
					}else{					
						return new Token(linha, coluna, tokenTable.getMAIOR(), lexema);
					}
					
				}else if(caracter == '!'){
					lexema+=caracter;
					proximoToken();
					
					if(caracter != '='){
						lexema+=caracter;
						proximoToken();
						Exception.DeferencaException(linha, coluna, lexema);
						
					}else{
						lexema+=caracter;
						proximoToken();
						return new Token(linha, coluna, tokenTable.getDIFERENCA(), lexema);
					}
					
				}else if(caracter == '('){
					lexema+=caracter;
					proximoToken();
					return new Token(linha, coluna, tokenTable.getABREPARENTESES(), lexema);
					
				}else if(caracter == ')'){
					lexema+=caracter;
					proximoToken();
					return new Token(linha, coluna, tokenTable.getFECHAPARENTESES(), lexema);
					
				}else if(caracter == '{'){
					lexema+=caracter;
					proximoToken();
					return new Token(linha, coluna, tokenTable.getABRECHAVE(), lexema);
					
				}else if(caracter == '}'){
					lexema+=caracter;
					proximoToken();
					return new Token(linha, coluna, tokenTable.getFECHACHAVE(), lexema);
					
				}else if(caracter == ';'){
					lexema+=caracter;
					proximoToken();
					return new Token(linha, coluna, tokenTable.getPONTOVIRGULA(), lexema);
					
				}else if(caracter == ','){
					lexema+=caracter;
					proximoToken();
					return new Token(linha, coluna, tokenTable.getVIRGULA(), lexema);
				}else{
					lexema+=caracter;
					Exception.NotValidException(linha, coluna, lexema);
				}
				
			}
			return new Token(linha, coluna, tokenTable.getEOF(), "EndOfFile");	
		
		
	}
	
	public void proximoToken(){
		
		try {
			caracter = (char) arquivo.read();			
			isBlank();
			
		} catch (IOException e) {			
			e.printStackTrace();
		}
	}	
	
	public void isBlank(){		
		if(caracter == '\t'){				
			coluna+=4;
		
		}else if(caracter == '\n'){
			linha+=1;
			coluna=0;
			
		}else{
			coluna+=1;
		}
	}
	
}
