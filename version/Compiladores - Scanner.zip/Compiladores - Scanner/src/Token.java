/*
 * Criado por: Henrique Dreyer
 * Data Inicio: 17/08/2015
 * 
 * 2015.2 Compiladores - Silvio Bandeira
 * 
 *	site: https://github.com/HenriqueDreyer/Compiladores
 */

public class Token {
	private int linha;
	private int coluna;
	private Enum token;
	private String lexema;
	
	public Token(int linha, int coluna, Enum token, String lexema){
		this.linha = linha;
		this.coluna = coluna;
		this.token = token;
		this.lexema = lexema;
	}

	public int getLinha() {
		return linha;
	}

	public int getColuna() {
		return coluna;
	}

	public Enum getToken() {
		return token;
	}

	public String getLexema() {
		return lexema;
	}

	public void setLinha(int linha) {
		this.linha = linha;
	}

	public void setColuna(int coluna) {
		this.coluna = coluna;
	}

	public void setToken(Enum token) {
		this.token = token;
	}

	public void setLexema(String lexema) {
		this.lexema = lexema;
	}
	
	
	
}
