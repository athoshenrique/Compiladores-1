/*
 * Criado por: Henrique Dreyer
 * Data Inicio: 17/08/2015
 * 
 * 2015.2 Compiladores - Silvio Bandeira
 * 
 *	site: https://github.com/HenriqueDreyer/Compiladores
 */

import java.io.FileNotFoundException;
import java.io.FileReader;

public class Main {

	public static void main(String[] args) {
		FileReader arquivo;
		AnalizadorLexico lexico;
		
		try {
			//arquivo = new FileReader(args[0]);
			arquivo = new FileReader("c:/Users/henrique.dreyer/workspace/Compiladores - Scanner/test.c");
			lexico = new AnalizadorLexico(arquivo);
			
			while(arquivo.ready()){
				lexico.Scanner();
			}
			
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

}
